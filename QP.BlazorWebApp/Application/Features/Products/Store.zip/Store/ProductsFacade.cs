﻿using Fluxor;
using MP;
using QP.BlazorWebApp.Application.Features.Products.Store.State;
using static QP.BlazorWebApp.Application.Features.Products.Store.Actions.ProductsActions;

namespace QP.BlazorWebApp.Application.Features.Products.Store
{
    public class ProductsFacade
    {
        private readonly IDispatcher _dispatcher;
        public IState<ProductsState> _state { get; }

        public ProductsFacade(IDispatcher dispatcher, IState<ProductsState> state)
        {
            _dispatcher = dispatcher;
            _state = state;

        }


        public void LoadProducts()
        {
            _dispatcher.Dispatch(new LoadProducts());
        }

        public bool IsLoading => _state.Value.ProductsLoading;
        public ICollection<ProductDto> Products => _state.Value.Products;
    }
}
