﻿using Fluxor;
using QP.BlazorWebApp.Application.Features.Products.Store.State;
using static QP.BlazorWebApp.Application.Features.Products.Store.Actions.ProductsActions;

namespace QP.BlazorWebApp.Application.Features.Products.Store.Reducers
{
    public class ProductsReducers
    {
        [ReducerMethod(typeof(LoadProducts))]
        public static ProductsState LoadProducts(ProductsState state) => state with { ProductsLoading = true };

        [ReducerMethod]
        public static ProductsState LoadProductsSuccess(ProductsState state, LoadProductsSuccess action)
        {

            return state with
            {
                ProductsLoading = false,
                Products = action.Products
            };
        }

        [ReducerMethod(typeof(LoadProductsError))]
        public static ProductsState LoadProductsError(ProductsState state)
        {
            return state with { ProductsLoading = false };

        }

    }
}
