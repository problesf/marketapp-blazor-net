﻿using Fluxor;
using MP;
using static QP.BlazorWebApp.Application.Features.Products.Store.Actions.ProductsActions;

namespace QP.BlazorWebApp.Application.Features.Products.Store.Effects
{
    public class ProductEffects
    {
        private readonly IMPApi _MPApi;

        public ProductEffects(IMPApi mpApi)
        {
            _MPApi = mpApi;

        }
        [EffectMethod]
        public async Task LoadProducts(LoadProducts action, IDispatcher dispatcher)
        {
            try
            {
                var response = await _MPApi.ProductAllAsync(null, null, null, null, null, null, null, null, null, null, null);


                dispatcher.Dispatch(new LoadProductsSuccess(response));



            }
            catch (ApiException e)
            {
                dispatcher.Dispatch(new LoadProductsError(e.Message));
            }

        }
    }
}
